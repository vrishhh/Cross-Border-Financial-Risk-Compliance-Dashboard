const { useState, useEffect, useRef } = React;

const initialSubsidiaries = [
  {
    id: "PARENT",
    name: "India (Parent)",
    country: "India",
    currency: "INR",
    liquidity: 5000,
    taxCompliance: 92,
    femaCompliance: 100,
    transferPricingScore: 95,
    withholdingTaxScore: 95
  },
  {
    id: "UK",
    name: "United Kingdom",
    country: "UK",
    currency: "GBP",
    liquidity: 2000000,
    taxCompliance: 85,
    femaCompliance: 90,
    transferPricingScore: 85,
    withholdingTaxScore: 88
  },
  {
    id: "SG",
    name: "Singapore",
    country: "Singapore",
    currency: "SGD",
    liquidity: 3000000,
    taxCompliance: 88,
    femaCompliance: 92,
    transferPricingScore: 88,
    withholdingTaxScore: 85
  },
  {
    id: "UAE",
    name: "United Arab Emirates",
    country: "UAE",
    currency: "AED",
    liquidity: 15000000,
    taxCompliance: 80,
    femaCompliance: 85,
    transferPricingScore: 80,
    withholdingTaxScore: 82
  },
  {
    id: "USA",
    name: "United States",
    country: "USA",
    currency: "USD",
    liquidity: 2500000,
    taxCompliance: 78,
    femaCompliance: 82,
    transferPricingScore: 75,
    withholdingTaxScore: 80
  }
];

const initialFxRates = [
  { pair: "INR/USD", rate: 83.45, change: 0.32, hedge: 65 },
  { pair: "INR/EUR", rate: 89.20, change: -0.18, hedge: 70 },
  { pair: "INR/GBP", rate: 104.50, change: 0.45, hedge: 75 },
  { pair: "INR/SGD", rate: 62.30, change: 0.12, hedge: 60 },
  { pair: "INR/AED", rate: 22.75, change: 0.05, hedge: 55 }
];

const complianceDeadlines = [
  { regulation: "GST Filing", daysRemaining: 15, status: "Pending", priority: "High" },
  { regulation: "Transfer Pricing Audit", daysRemaining: 45, status: "In Progress", priority: "High" },
  { regulation: "Income Tax Return", daysRemaining: 23, status: "Pending", priority: "Critical" },
  { regulation: "FEMA Reporting", daysRemaining: 10, status: "Pending", priority: "High" },
  { regulation: "eBRC Filing", daysRemaining: 7, status: "Submitted", priority: "Medium" }
];

const taxRisks = [
  { type: "Transfer Pricing", exposure: 2500000, risk: 35, status: "Under Review" },
  { type: "Withholding Tax", exposure: 850000, risk: 22, status: "Compliant" },
  { type: "Base Erosion", exposure: 1200000, risk: 45, status: "At Risk" },
  { type: "DTAA Benefits", exposure: 500000, risk: 15, status: "Compliant" }
];

function Dashboard() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [selectedSubsidiary, setSelectedSubsidiary] = useState("PARENT");
  const [viewMode, setViewMode] = useState("overview");
  const [subsidiaries, setSubsidiaries] = useState(initialSubsidiaries);
  const [fxRates, setFxRates] = useState(initialFxRates);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
      
      // Simulate real-time FX rate updates
      setFxRates(prevRates => 
        prevRates.map(rate => ({
          ...rate,
          rate: rate.rate + (Math.random() - 0.5) * 0.1,
          change: rate.change + (Math.random() - 0.5) * 0.05
        }))
      );

      // Simulate compliance score updates
      setSubsidiaries(prevSubs => 
        prevSubs.map(sub => ({
          ...sub,
          taxCompliance: Math.min(100, Math.max(70, sub.taxCompliance + (Math.random() - 0.5) * 0.5))
        }))
      );
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  const currentSubsidiary = subsidiaries.find(s => s.id === selectedSubsidiary) || subsidiaries[0];

  const getCriticalAlerts = () => {
    const alerts = [];
    complianceDeadlines.forEach(deadline => {
      if (deadline.priority === "Critical" && deadline.daysRemaining < 30) {
        alerts.push({
          type: "critical",
          message: `${deadline.regulation} due in ${deadline.daysRemaining} days`
        });
      }
    });
    
    if (currentSubsidiary.taxCompliance < 85) {
      alerts.push({
        type: "warning",
        message: `${currentSubsidiary.name} tax compliance below threshold: ${currentSubsidiary.taxCompliance.toFixed(1)}%`
      });
    }

    fxRates.forEach(rate => {
      if (Math.abs(rate.change) > 0.3) {
        alerts.push({
          type: "warning",
          message: `${rate.pair} experiencing high volatility: ${rate.change > 0 ? '+' : ''}${rate.change.toFixed(2)}%`
        });
      }
    });

    return alerts.slice(0, 3);
  };

  const formatCurrency = (value, currency) => {
    if (currency === "INR") {
      return `₹${(value / 100000).toFixed(2)}L`;
    }
    const symbols = { GBP: "£", USD: "$", SGD: "S$", AED: "AED" };
    return `${symbols[currency] || currency}${(value / 1000000).toFixed(2)}M`;
  };

  const getComplianceColor = (score) => {
    if (score >= 90) return "success";
    if (score >= 75) return "warning";
    return "error";
  };

  const handleExport = () => {
    const report = {
      timestamp: new Date().toISOString(),
      subsidiary: currentSubsidiary.name,
      metrics: {
        taxCompliance: currentSubsidiary.taxCompliance,
        femaCompliance: currentSubsidiary.femaCompliance,
        liquidity: currentSubsidiary.liquidity,
        currency: currentSubsidiary.currency
      },
      fxRates: fxRates,
      deadlines: complianceDeadlines
    };
    console.log("Export Report:", report);
    alert("Report exported to console");
  };

  return (
    <div className="dashboard">
      <aside className={`sidebar ${sidebarCollapsed ? 'collapsed' : ''}`}>
        <div className="sidebar-header">
          <h2 className="sidebar-title">Navigation</h2>
        </div>
        <ul className="nav-menu">
          <li className="nav-item">
            <a className="nav-link active" onClick={() => setViewMode('overview')}>
              <span className="nav-icon">📊</span>
              <span>Overview</span>
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link" onClick={() => setViewMode('compliance')}>
              <span className="nav-icon">✓</span>
              <span>Compliance</span>
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link" onClick={() => setViewMode('fx')}>
              <span className="nav-icon">💱</span>
              <span>FX Exposure</span>
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link" onClick={() => setViewMode('liquidity')}>
              <span className="nav-icon">💰</span>
              <span>Liquidity</span>
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link" onClick={() => setViewMode('tax')}>
              <span className="nav-icon">📋</span>
              <span>Tax Risks</span>
            </a>
          </li>
        </ul>
      </aside>

      <main className="main-content">
        <header className="header">
          <div className="header-left">
            <button className="menu-toggle" onClick={() => setSidebarCollapsed(!sidebarCollapsed)}>
              ☰
            </button>
            <h1 className="header-title">Cross-Border Financial Risk &amp; Compliance</h1>
          </div>
          <div className="header-controls">
            <select 
              className="select-control" 
              value={selectedSubsidiary}
              onChange={(e) => setSelectedSubsidiary(e.target.value)}
            >
              {subsidiaries.map(sub => (
                <option key={sub.id} value={sub.id}>{sub.name}</option>
              ))}
            </select>
            <div className="view-mode-toggle">
              <button 
                className={`view-mode-btn ${viewMode === 'overview' ? 'active' : ''}`}
                onClick={() => setViewMode('overview')}
              >
                Overview
              </button>
              <button 
                className={`view-mode-btn ${viewMode === 'detailed' ? 'active' : ''}`}
                onClick={() => setViewMode('detailed')}
              >
                Detailed
              </button>
              <button 
                className={`view-mode-btn ${viewMode === 'forecast' ? 'active' : ''}`}
                onClick={() => setViewMode('forecast')}
              >
                Forecast
              </button>
            </div>
            <button className="btn btn-primary" onClick={handleExport}>
              📥 Export
            </button>
          </div>
        </header>

        <div className="content">
          {getCriticalAlerts().length > 0 && (
            <div className="alerts-section">
              {getCriticalAlerts().map((alert, idx) => (
                <div key={idx} className={`alert alert-${alert.type}`}>
                  <span>{alert.message}</span>
                  <span>⚠</span>
                </div>
              ))}
            </div>
          )}

          <div className="metrics-grid">
            <div className="metric-card">
              <div className="metric-header">
                <span className="metric-label">Tax Compliance</span>
                <span className="metric-icon">📊</span>
              </div>
              <div className="metric-value">{currentSubsidiary.taxCompliance.toFixed(1)}%</div>
              <div className={`metric-change ${currentSubsidiary.taxCompliance >= 90 ? 'positive' : 'negative'}`}>
                <span>{currentSubsidiary.taxCompliance >= 90 ? '↑' : '↓'}</span>
                <span>{currentSubsidiary.taxCompliance >= 90 ? 'Compliant' : 'Action Required'}</span>
              </div>
            </div>

            <div className="metric-card">
              <div className="metric-header">
                <span className="metric-label">FEMA Compliance</span>
                <span className="metric-icon">✓</span>
              </div>
              <div className="metric-value">{currentSubsidiary.femaCompliance}%</div>
              <div className="metric-change positive">
                <span>↑</span>
                <span>On Track</span>
              </div>
            </div>

            <div className="metric-card">
              <div className="metric-header">
                <span className="metric-label">Liquidity Position</span>
                <span className="metric-icon">💰</span>
              </div>
              <div className="metric-value">
                {formatCurrency(currentSubsidiary.liquidity, currentSubsidiary.currency)}
              </div>
              <div className="metric-change positive">
                <span>↑</span>
                <span>Healthy</span>
              </div>
            </div>

            <div className="metric-card">
              <div className="metric-header">
                <span className="metric-label">Transfer Pricing</span>
                <span className="metric-icon">📋</span>
              </div>
              <div className="metric-value">{currentSubsidiary.transferPricingScore}%</div>
              <div className="metric-change positive">
                <span>↑</span>
                <span>Compliant</span>
              </div>
            </div>
          </div>

          {(viewMode === 'overview' || viewMode === 'detailed') && (
            <>
              <div className="chart-card">
                <div className="chart-header">
                  <h3 className="chart-title">Real-Time FX Exposure</h3>
                  <p className="chart-subtitle">Live exchange rates &amp; hedge ratios</p>
                </div>
                <div className="fx-grid">
                  {fxRates.map((fx, idx) => (
                    <div key={idx} className="fx-card">
                      <div className="fx-pair">{fx.pair}</div>
                      <div className="fx-rate">₹{fx.rate.toFixed(2)}</div>
                      <div className={`fx-change ${fx.change >= 0 ? 'positive' : 'negative'}`}>
                        <span>{fx.change >= 0 ? '↑' : '↓'}</span>
                        <span>{fx.change >= 0 ? '+' : ''}{fx.change.toFixed(2)}%</span>
                      </div>
                      <div className="fx-hedge">Hedge Ratio: {fx.hedge}%</div>
                      <div className="progress-bar">
                        <div 
                          className="progress-fill success" 
                          style={{ width: `${fx.hedge}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="charts-grid">
                <div className="chart-card">
                  <div className="chart-header">
                    <h3 className="chart-title">Compliance Status Overview</h3>
                    <p className="chart-subtitle">Regulatory compliance by category</p>
                  </div>
                  <div className="compliance-grid">
                    <div className="compliance-item">
                      <div className="compliance-type">FEMA</div>
                      <div className="compliance-score" style={{ color: 'var(--color-success)' }}>
                        {currentSubsidiary.femaCompliance}%
                      </div>
                      <div className="progress-bar">
                        <div 
                          className="progress-fill success" 
                          style={{ width: `${currentSubsidiary.femaCompliance}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="compliance-item">
                      <div className="compliance-type">Transfer Pricing</div>
                      <div className="compliance-score" style={{ color: 'var(--color-success)' }}>
                        {currentSubsidiary.transferPricingScore}%
                      </div>
                      <div className="progress-bar">
                        <div 
                          className="progress-fill success" 
                          style={{ width: `${currentSubsidiary.transferPricingScore}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="compliance-item">
                      <div className="compliance-type">Withholding Tax</div>
                      <div className="compliance-score" style={{ color: 'var(--color-success)' }}>
                        {currentSubsidiary.withholdingTaxScore}%
                      </div>
                      <div className="progress-bar">
                        <div 
                          className="progress-fill success" 
                          style={{ width: `${currentSubsidiary.withholdingTaxScore}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="compliance-item">
                      <div className="compliance-type">Tax Audit</div>
                      <div className="compliance-score" style={{ color: getComplianceColor(currentSubsidiary.taxCompliance) === 'success' ? 'var(--color-success)' : 'var(--color-warning)' }}>
                        {currentSubsidiary.taxCompliance.toFixed(1)}%
                      </div>
                      <div className="progress-bar">
                        <div 
                          className={`progress-fill ${getComplianceColor(currentSubsidiary.taxCompliance)}`}
                          style={{ width: `${currentSubsidiary.taxCompliance}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="chart-card">
                  <div className="chart-header">
                    <h3 className="chart-title">Liquidity Across Subsidiaries</h3>
                    <p className="chart-subtitle">Multi-currency cash positions</p>
                  </div>
                  <div style={{ marginTop: '20px' }}>
                    {subsidiaries.map((sub, idx) => (
                      <div key={idx} style={{ marginBottom: '16px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                          <span style={{ fontSize: 'var(--font-size-sm)', fontWeight: 'var(--font-weight-medium)' }}>
                            {sub.name}
                          </span>
                          <span style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-secondary)' }}>
                            {formatCurrency(sub.liquidity, sub.currency)}
                          </span>
                        </div>
                        <div className="progress-bar">
                          <div 
                            className="progress-fill success" 
                            style={{ width: `${(sub.liquidity / 15000000) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}

          <div className="table-card">
            <div className="chart-header">
              <h3 className="chart-title">Compliance Calendar</h3>
              <p className="chart-subtitle">Upcoming regulatory deadlines</p>
            </div>
            <table className="table">
              <thead>
                <tr>
                  <th>Regulation</th>
                  <th>Days Remaining</th>
                  <th>Status</th>
                  <th>Priority</th>
                </tr>
              </thead>
              <tbody>
                {complianceDeadlines.map((deadline, idx) => (
                  <tr key={idx}>
                    <td>{deadline.regulation}</td>
                    <td>{deadline.daysRemaining} days</td>
                    <td>
                      <span className={`status-badge status-${deadline.status === 'Submitted' ? 'compliant' : deadline.daysRemaining < 15 ? 'critical' : 'warning'}`}>
                        {deadline.status}
                      </span>
                    </td>
                    <td>
                      <span className={`status-badge status-${deadline.priority === 'Critical' ? 'critical' : deadline.priority === 'High' ? 'warning' : 'compliant'}`}>
                        {deadline.priority}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {viewMode === 'detailed' && (
            <div className="table-card">
              <div className="chart-header">
                <h3 className="chart-title">Tax Risk Assessment</h3>
                <p className="chart-subtitle">Detailed exposure &amp; risk analysis</p>
              </div>
              <table className="table">
                <thead>
                  <tr>
                    <th>Risk Type</th>
                    <th>Exposure</th>
                    <th>Risk Score</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {taxRisks.map((risk, idx) => (
                    <tr key={idx}>
                      <td>{risk.type}</td>
                      <td>₹{(risk.exposure / 100000).toFixed(2)}L</td>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <span>{risk.risk}%</span>
                          <div className="progress-bar" style={{ width: '100px' }}>
                            <div 
                              className={`progress-fill ${risk.risk > 40 ? 'error' : risk.risk > 25 ? 'warning' : 'success'}`}
                              style={{ width: `${risk.risk}%` }}
                            ></div>
                          </div>
                        </div>
                      </td>
                      <td>
                        <span className={`status-badge status-${risk.status === 'Compliant' ? 'compliant' : risk.status === 'At Risk' ? 'critical' : 'warning'}`}>
                          {risk.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <div style={{ marginTop: '24px', padding: '12px', backgroundColor: 'var(--color-bg-8)', borderRadius: 'var(--radius-base)', fontSize: 'var(--font-size-sm)', color: 'var(--color-text-secondary)', textAlign: 'center' }}>
            Last updated: {currentTime.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })} IST • Real-time data refresh every 5 seconds
          </div>
        </div>
      </main>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Dashboard />);